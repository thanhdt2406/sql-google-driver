create definer = root@localhost trigger cusUpdate
    after update
    on customer
    for each row
BEGIN
    UPDATE Orders SET cID = NEW.cID WHERE cID = OLD.cID;
END;

