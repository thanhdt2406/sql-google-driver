create
    definer = root@localhost procedure delProduct(IN TenSP varchar(25))
BEGIN
    DELETE FROM Product WHERE pName = TenSP;
END;

