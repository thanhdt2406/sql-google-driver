create
    definer = root@localhost procedure EDITPRODUCT(IN PRODUCTID int, IN NEWPRODUCTCODE varchar(20),
                                                   IN NEWPRODUCTNAME varchar(30), IN NEWPRODUCTPRICE int,
                                                   IN NEWPRODUCTAMOUNT int, IN NEWPRODUCTDESCRIPTION varchar(1000),
                                                   IN NEWPRODUCTSTATUS bit)
BEGIN
    UPDATE PRODUCTS
    SET PRODUCTCODE        = NEWPRODUCTCODE,
        PRODUCTNAME        = NEWPRODUCTNAME,
        PRODUCTPRICE       = NEWPRODUCTPRICE,
        PRODUCTAMOUNT      = NEWPRODUCTAMOUNT,
        PRODUCTDESCRIPTION = NEWPRODUCTDESCRIPTION,
        PRODUCTSTATUS      = NEWPRODUCTSTATUS
    WHERE ID = PRODUCTID;
END;

