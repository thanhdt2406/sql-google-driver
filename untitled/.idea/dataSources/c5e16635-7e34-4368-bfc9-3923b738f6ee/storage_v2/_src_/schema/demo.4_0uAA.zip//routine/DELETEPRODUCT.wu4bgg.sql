create
    definer = root@localhost procedure DELETEPRODUCT(IN PRODUCTID int)
BEGIN
    DELETE FROM PRODUCTS WHERE ID = PRODUCTID;
END;

