create
    definer = root@localhost procedure ADDPRODUCT(IN ID int, IN PRODUCTCODE varchar(20), IN PRODUCTNAME varchar(30),
                                                  IN PRODUCTPRICE int, IN PRODUCTAMOUNT int,
                                                  IN PRODUCTDESCRIPTION varchar(1000), IN PRODUCTSTATUS bit)
BEGIN
    INSERT INTO PRODUCTS
        VALUE (ID,
               PRODUCTCODE,
               PRODUCTNAME,
               PRODUCTPRICE,
               PRODUCTAMOUNT,
               PRODUCTDESCRIPTION,
               PRODUCTSTATUS);
END;

