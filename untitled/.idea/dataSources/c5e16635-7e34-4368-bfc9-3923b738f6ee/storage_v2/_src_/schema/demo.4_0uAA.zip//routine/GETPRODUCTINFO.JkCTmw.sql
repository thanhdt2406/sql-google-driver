create
    definer = root@localhost procedure GETPRODUCTINFO()
BEGIN
    SELECT * FROM PRODUCTS;
END;

