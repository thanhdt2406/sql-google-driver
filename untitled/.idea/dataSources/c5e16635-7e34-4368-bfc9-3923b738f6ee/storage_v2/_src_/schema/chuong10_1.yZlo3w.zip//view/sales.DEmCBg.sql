create definer = root@localhost view sales as
select sum((`chuong10_1`.`orderdetail`.`odQTY` * `chuong10_1`.`product`.`pPrice`)) AS `Sales`
from ((`chuong10_1`.`orders` join `chuong10_1`.`orderdetail` on ((`chuong10_1`.`orders`.`oID` = `chuong10_1`.`orderdetail`.`oID`)))
         join `chuong10_1`.`product` on ((`chuong10_1`.`product`.`pID` = `chuong10_1`.`orderdetail`.`pID`)));

